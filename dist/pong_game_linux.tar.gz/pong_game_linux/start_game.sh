#!/bin/bash
java -jar ./pong_game.jar
